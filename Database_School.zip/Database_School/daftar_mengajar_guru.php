<?php
session_start();
ob_start();

require_once 'navbar1.php';
require_once 'koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

if ($_SESSION['role'] !== 'guru') {
    header("Location: dashboard.php");
    exit;
}

$user_id = $_SESSION['id'];

// Ambil daftar kelas dan mata pelajaran milik guru yang login
$sql = "SELECT
            siswa.kelas,
            mapel.id AS mapel_id,
            mapel.nama_mapel,
            COUNT(DISTINCT siswa.id) AS jumlah_siswa
        FROM mengajar
        JOIN siswa ON mengajar.siswa_id = siswa.id
        JOIN mapel ON mengajar.mapel_id = mapel.id
        JOIN guru ON mapel.guru_id = guru.id
        WHERE guru.user_id = ?
        GROUP BY siswa.kelas, mapel.id, mapel.nama_mapel
        ORDER BY siswa.kelas ASC, mapel.nama_mapel ASC";

$stmt = mysqli_prepare($koneksi, $sql);

if (!$stmt) {
    die("Query gagal: " . mysqli_error($koneksi));
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$query = mysqli_stmt_get_result($stmt);

function amanDaftarGuru($teks) {
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Daftar Kelas yang Diajar</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.4/css/dataTables.bootstrap5.min.css">

    <style>
        body {
            background: #f8f9fc;
            color: #334155;
            font-family: Arial, sans-serif;
        }

        .mengajar-page {
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 16px;
        }

        .mengajar-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
        }

        .mengajar-header {
            padding: 24px;
            border-bottom: 1px solid #e5e7eb;
        }

        .mengajar-title {
            color: #4f46e5;
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .mengajar-subtitle {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 0;
        }

        .mengajar-body {
            padding: 24px;
        }

        .table {
            width: 100% !important;
            margin-bottom: 0;
        }

        .table thead th {
            background: #f1f5f9;
            color: #475569;
            font-size: 13px;
            font-weight: 700;
            vertical-align: middle;
        }

        .table tbody td {
            font-size: 14px;
            vertical-align: middle;
        }

        .btn-lihat {
            border-radius: 7px;
        }

        .dataTables_wrapper {
            font-size: 14px;
        }

        @media (max-width: 576px) {
            .mengajar-page {
                margin: 20px auto;
                padding: 0 10px;
            }

            .mengajar-header,
            .mengajar-body {
                padding: 16px;
            }

            .mengajar-title {
                font-size: 21px;
            }
        }
    </style>
</head>

<body>

<main class="mengajar-page">

    <div class="mengajar-card">

        <div class="mengajar-header">
            <h1 class="mengajar-title">
                <i class="bi bi-journal-bookmark"></i>
                Daftar Kelas yang Diajar
            </h1>

            <p class="mengajar-subtitle">
                Daftar kelas dan mata pelajaran yang kamu ajar.
            </p>
        </div>

        <div class="mengajar-body">

            <div class="table-responsive">
                <table id="tabelMengajar" class="table table-bordered table-hover align-middle">

                    <thead>
                        <tr>
                            <th style="width: 60px;">No</th>
                            <th>Kelas</th>
                            <th>Mata Pelajaran</th>
                            <th>Jumlah Siswa</th>
                            <th style="width: 90px;">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (mysqli_num_rows($query) > 0): ?>

                        <?php $no = 1; ?>

                        <?php while ($row = mysqli_fetch_assoc($query)): ?>

                            <tr>
                                <td><?= $no++; ?></td>

                                <td>
                                    <?= amanDaftarGuru($row['kelas']); ?>
                                </td>

                                <td>
                                    <?= amanDaftarGuru($row['nama_mapel']); ?>
                                </td>

                                <td>
                                    <?= (int) $row['jumlah_siswa']; ?> siswa
                                </td>

                                <td>
                                    <a
                                        href="tambah_nilai.php?kelas=<?= urlencode($row['kelas']); ?>&mapel_id=<?= (int) $row['mapel_id']; ?>"
                                        class="btn btn-sm btn-primary btn-lihat"
                                    >
                                        Lihat
                                    </a>
                                </td>
                            </tr>

                        <?php endwhile; ?>

                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <?php if (mysqli_num_rows($query) == 0): ?>
                <div class="alert alert-info text-center mt-3 mb-0">
                    Belum ada kelas yang kamu ajar.
                </div>
            <?php endif; ?>

        </div>
    </div>

</main>

<?php require 'footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function () {
    $('#tabelMengajar').DataTable({
        language: {
            search: "Cari:",
            lengthMenu: "Tampilkan _MENU_ data per halaman",
            info: "Menampilkan halaman _PAGE_ dari _PAGES_",
            infoEmpty: "Tidak ada data tersedia",
            zeroRecords: "Data tidak ditemukan",
            emptyTable: "Belum ada data mengajar",
            paginate: {
                previous: "Sebelumnya",
                next: "Selanjutnya"
            }
        }
    });
});
</script>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($koneksi);
ob_end_flush();
?>
