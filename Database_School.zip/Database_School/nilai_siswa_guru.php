<?php
session_start();
ob_start();

require_once 'koneksi.php';
require_once 'navbar1.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

if ($_SESSION['role'] !== 'guru') {
    header("Location: dashboard.php");
    exit;
}

$user_id = $_SESSION['id'];
$kelas = trim($_GET['kelas'] ?? '');
$mapel_id = filter_input(INPUT_GET, 'mapel_id', FILTER_VALIDATE_INT);

if ($kelas === '' || !$mapel_id) {
    header("Location: daftar_mengajar_guru.php");
    exit;
}

// Pastikan kelas dan mapel memang diajar guru yang login
$sql_akses = "SELECT COUNT(*) AS total
              FROM mengajar
              JOIN siswa ON mengajar.siswa_id = siswa.id
              JOIN mapel ON mengajar.mapel_id = mapel.id
              JOIN guru ON mapel.guru_id = guru.id
              WHERE guru.user_id = ?
                AND siswa.kelas = ?
                AND mapel.id = ?";

$stmt = mysqli_prepare($koneksi, $sql_akses);
mysqli_stmt_bind_param($stmt, "isi", $user_id, $kelas, $mapel_id);
mysqli_stmt_execute($stmt);

$akses = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($akses['total'] == 0) {
    die("Kamu tidak memiliki akses ke kelas dan mata pelajaran ini.");
}

// Ambil nama mata pelajaran
$sql_mapel = "SELECT nama_mapel FROM mapel WHERE id = ?";
$stmt = mysqli_prepare($koneksi, $sql_mapel);
mysqli_stmt_bind_param($stmt, "i", $mapel_id);
mysqli_stmt_execute($stmt);

$data_mapel = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
$nama_mapel = $data_mapel['nama_mapel'];

// Ambil seluruh siswa dalam kelas
$sql = "SELECT
            siswa.id AS siswa_id,
            siswa.nis,
            siswa.nama,
            siswa.kelas,
            nilai_rapor.id AS nilai_id,
            nilai_rapor.nilai_kkm,
            nilai_rapor.nilai_pengetahuan,
            nilai_rapor.nilai_keterampilan,
            nilai_rapor.keterangan
        FROM siswa
        LEFT JOIN nilai_rapor
            ON siswa.id = nilai_rapor.siswa_id
            AND nilai_rapor.mapel_id = ?
        WHERE siswa.kelas = ?
        ORDER BY siswa.nama ASC";

$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "is", $mapel_id, $kelas);
mysqli_stmt_execute($stmt);

$query = mysqli_stmt_get_result($stmt);

function amanNilaiGuru($teks) {
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

require_once 'navbar1.php';
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Daftar Nilai Siswa - SIACAD</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            background: #f8f9fc;
            color: #334155;
            font-family: Arial, sans-serif;
        }

        .nilai-page {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 16px;
        }

        .nilai-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,.04);
        }

        .nilai-header {
            padding: 24px;
            border-bottom: 1px solid #e5e7eb;
        }

        .nilai-title {
            font-size: 25px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #334155;
        }

        .nilai-subtitle {
            color: #64748b;
            margin-bottom: 0;
            font-size: 14px;
        }

        .nilai-body {
            padding: 24px;
        }

        .table {
            white-space: nowrap;
            margin-bottom: 0;
        }

        .table thead th {
            background: #f1f5f9;
            font-size: 13px;
            padding: 13px 10px;
        }

        .table tbody td {
            font-size: 14px;
            padding: 12px 10px;
            vertical-align: middle;
        }

        .badge-nilai {
            display: inline-block;
            min-width: 35px;
            padding: 6px 9px;
            border-radius: 6px;
            background: #0d6efd;
            color: white;
            font-weight: 700;
        }

        .badge-akhir {
            background: #198754;
        }
    </style>
</head>

<body>

<main class="nilai-page">

    <div class="nilai-card">

        <div class="nilai-header">
            <h1 class="nilai-title">Daftar Nilai Siswa</h1>

            <p class="nilai-subtitle">
                Kelas: <strong><?= amanNilaiGuru($kelas); ?></strong>
                &nbsp; | &nbsp;
                Mata Pelajaran:
                <strong><?= amanNilaiGuru($nama_mapel); ?></strong>
            </p>
        </div>

        <div class="nilai-body">

            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] == 'berhasil'): ?>
                    <div class="alert alert-success">
                        Data nilai berhasil diproses.
                    </div>
                <?php elseif ($_GET['status'] == 'gagal'): ?>
                    <div class="alert alert-danger">
                        Gagal memproses data nilai.
                    </div>
                <?php elseif ($_GET['status'] == 'duplikat'): ?>
                    <div class="alert alert-warning">
                        Nilai siswa untuk mata pelajaran ini sudah tersedia.
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="table-responsive">

                <table id="tabelNilai" class="table table-bordered table-hover text-center align-middle">

                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Siswa</th>
                            <th>KKM</th>
                            <th>Pengetahuan</th>
                            <th>Keterampilan</th>
                            <th>Nilai Akhir</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php $no = 1; ?>

                    <?php while ($row = mysqli_fetch_assoc($query)): ?>

                        <?php
                        $ada_nilai = $row['nilai_id'] !== null;

                        $nilai_akhir = $ada_nilai
                            ? round(($row['nilai_pengetahuan'] + $row['nilai_keterampilan']) / 2)
                            : null;
                        ?>

                        <tr>
                            <td><?= $no++; ?></td>

                            <td class="text-start">
                                <strong><?= amanNilaiGuru($row['nama']); ?></strong>
                            </td>

                            <td>
                                <?= $ada_nilai ? (int)$row['nilai_kkm'] : '-'; ?>
                            </td>

                            <td>
                                <?= $ada_nilai
                                    ? '<span class="badge-nilai">' . (int)$row['nilai_pengetahuan'] . '</span>'
                                    : '-'; ?>
                            </td>

                            <td>
                                <?= $ada_nilai
                                    ? '<span class="badge-nilai">' . (int)$row['nilai_keterampilan'] . '</span>'
                                    : '-'; ?>
                            </td>

                            <td>
                                <?= $ada_nilai
                                    ? '<span class="badge-nilai badge-akhir">' . $nilai_akhir . '</span>'
                                    : 'Belum ada'; ?>
                            </td>

                            <td>
                                <?php if ($ada_nilai): ?>
                                    <?php if ($nilai_akhir >= $row['nilai_kkm']): ?>
                                        <span class="text-success">Lulus</span>
                                    <?php else: ?>
                                        <span class="text-danger">Tidak Lulus</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($ada_nilai): ?>

                                    <button
                                        type="button"
                                        class="btn btn-sm btn-warning mb-1"
                                        onclick="editNilai(
                                            <?= (int)$row['siswa_id']; ?>,
                                            <?= (int)$row['nilai_kkm']; ?>,
                                            <?= (int)$row['nilai_pengetahuan']; ?>,
                                            <?= (int)$row['nilai_keterampilan']; ?>,
                                            <?= (int)$row['nilai_id']; ?>
                                        )">
                                        Edit
                                    </button>

                                    <form action="aksi_nilai_guru.php"
                                          method="POST"
                                          onsubmit="return confirm('Yakin ingin menghapus nilai ini?');">

                                        <input type="hidden" name="aksi" value="hapus">
                                        <input type="hidden" name="nilai_id" value="<?= (int)$row['nilai_id']; ?>">
                                        <input type="hidden" name="siswa_id" value="<?= (int)$row['siswa_id']; ?>">
                                        <input type="hidden" name="kelas" value="<?= amanNilaiGuru($kelas); ?>">
                                        <input type="hidden" name="mapel_id" value="<?= (int)$mapel_id; ?>">

                                        <button type="submit" class="btn btn-sm btn-danger">
                                            Hapus
                                        </button>
                                    </form>

                                <?php else: ?>

                                    <button
                                        type="button"
                                        class="btn btn-sm btn-primary"
                                        onclick="tambahNilai(<?= (int)$row['siswa_id']; ?>)">
                                        Tambah
                                    </button>

                                <?php endif; ?>
                            </td>
                        </tr>

                    <?php endwhile; ?>

                    </tbody>
                </table>
            </div>

            <a href="daftar_mengajar_guru.php" class="btn btn-secondary mt-3">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>

        </div>
    </div>

</main>

<!-- Modal Tambah dan Edit Nilai -->
<div class="modal fade" id="modalNilai" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">

            <form action="aksi_nilai_guru.php" method="POST">

                <div class="modal-header">
                    <h5 class="modal-title" id="judulModal">Tambah Nilai Siswa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <input type="hidden" name="aksi" id="aksi">
                    <input type="hidden" name="siswa_id" id="siswa_id">
                    <input type="hidden" name="nilai_id" id="nilai_id">

                    <input type="hidden" name="kelas" value="<?= amanNilaiGuru($kelas); ?>">
                    <input type="hidden" name="mapel_id" value="<?= (int)$mapel_id; ?>">

                    <div class="mb-3">
                        <label class="form-label">KKM</label>
                        <input type="number" name="nilai_kkm" id="nilai_kkm"
                               class="form-control" min="0" max="100" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nilai Pengetahuan</label>
                        <input type="number" name="nilai_pengetahuan" id="nilai_pengetahuan"
                               class="form-control" min="0" max="100" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nilai Keterampilan</label>
                        <input type="number" name="nilai_keterampilan" id="nilai_keterampilan"
                               class="form-control" min="0" max="100" required>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Batal
                    </button>

                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<?php require 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>

<script>
const modalNilai = new bootstrap.Modal(document.getElementById('modalNilai'));

function tambahNilai(siswaId) {
    document.getElementById('judulModal').innerText = 'Tambah Nilai Siswa';
    document.getElementById('aksi').value = 'tambah';
    document.getElementById('siswa_id').value = siswaId;
    document.getElementById('nilai_id').value = '';

    document.getElementById('nilai_kkm').value = 75;
    document.getElementById('nilai_pengetahuan').value = '';
    document.getElementById('nilai_keterampilan').value = '';

    modalNilai.show();
}

function editNilai(siswaId, kkm, pengetahuan, keterampilan, nilaiId) {
    document.getElementById('judulModal').innerText = 'Edit Nilai Siswa';
    document.getElementById('aksi').value = 'edit';
    document.getElementById('siswa_id').value = siswaId;
    document.getElementById('nilai_id').value = nilaiId;

    document.getElementById('nilai_kkm').value = kkm;
    document.getElementById('nilai_pengetahuan').value = pengetahuan;
    document.getElementById('nilai_keterampilan').value = keterampilan;

    modalNilai.show();
}

$(document).ready(function () {
    $('#tabelNilai').DataTable({
        pageLength: 10,
        language: {
            search: "Cari:",
            lengthMenu: "Tampilkan _MENU_ data per halaman",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            infoEmpty: "Tidak ada data",
            zeroRecords: "Data tidak ditemukan",
            paginate: {
                previous: "Sebelumnya",
                next: "Selanjutnya"
            }
        }
    });
});
</script>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($koneksi);
ob_end_flush();
?>
