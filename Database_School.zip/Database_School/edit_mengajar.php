<?php
ob_start();

require 'koneksi.php';
require_once 'navbar1.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>
            alert('ID mengajar tidak valid');
            window.location.href='data_mengajar.php';
          </script>";
    exit;
}

$id = (int) $_GET['id'];

$sql = "SELECT
            mengajar.id,
            mengajar.siswa_id,
            mengajar.mapel_id,
            siswa.kelas,
            guru.nama AS nama_guru,
            mapel.nama_mapel,
            mapel.kode_mapel
        FROM mengajar
        JOIN siswa ON mengajar.siswa_id = siswa.id
        JOIN mapel ON mengajar.mapel_id = mapel.id
        JOIN guru ON mapel.guru_id = guru.id
        WHERE mengajar.id = $id";

$query = mysqli_query($koneksi, $sql);

if (!$query) {
    die("Query gagal: " . mysqli_error($koneksi));
}

$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>
            alert('Data mengajar tidak ditemukan');
            window.location.href='daftar_mengajar.php';
          </script>";
    exit;
}

$sql_siswa = "SELECT id, nama, kelas FROM siswa ORDER BY kelas ASC, nama ASC";
$query_siswa = mysqli_query($koneksi, $sql_siswa);

// Ambil daftar mata pelajaran
$sql_mapel = "SELECT id, nama_mapel, kode_mapel FROM mapel ORDER BY nama_mapel ASC";
$query_mapel = mysqli_query($koneksi, $sql_mapel);

function aman($teks) {
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}
?>

<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Edit Data Mengajar</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            background: #f8f9fc;
            color: #334155;
            font-family: Arial, sans-serif;
        }

        .edit-page {
            max-width: 700px;
            margin: 35px auto;
            padding: 0 15px;
        }

        .edit-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.04);
        }

        .edit-header {
            padding: 22px;
            border-bottom: 1px solid #e5e7eb;
        }

        .edit-title {
            color: #4f46e5;
            font-size: 23px;
            font-weight: 700;
            margin: 0;
        }

        .edit-body {
            padding: 24px;
        }

        .form-label {
            font-weight: 600;
            color: #475569;
        }

        .form-control,
        .form-select {
            padding: 10px;
        }

        .btn-simpan {
            background: #4f46e5;
            color: white;
        }

        .btn-simpan:hover {
            background: #4338ca;
            color: white;
        }
    </style>
</head>

<body>

<div class="edit-page">

    <div class="edit-card">

        <div class="edit-header">
            <h3 class="edit-title">
                <i class="bi bi-pencil-square"></i>
                Edit Data Mengajar
            </h3>

            <small class="text-muted">
                Silakan ubah data mengajar di bawah ini.
            </small>
        </div>

        <div class="edit-body">

            <form action="aksi_mengajar.php" method="POST">

                <input type="hidden" name="id" value="<?= (int) $data['id']; ?>">

                <input type="hidden" name="aksi" value="edit">

                <div class="mb-3">
                    <label class="form-label">Guru Pengajar</label>

                    <input
                        type="text"
                        class="form-control"
                        value="<?= aman($data['nama_guru']); ?>"
                        readonly
                    >

                    <small class="text-muted">
                        Guru mengikuti mata pelajaran yang dipilih.
                    </small>
                </div>

                <div class="mb-3">
    <label class="form-label">Siswa</label>

    <select name="siswa_id" class="form-select" required>

        <option value="">Pilih Siswa</option>

        <?php while ($siswa = mysqli_fetch_assoc($query_siswa)) : ?>

            <option
                value="<?= (int) $siswa['id']; ?>"
                <?= ($siswa['id'] == $data['siswa_id']) ? 'selected' : ''; ?>
            >
                <?= aman($siswa['nama']); ?>
                - <?= aman($siswa['kelas']); ?>
            </option>

        <?php endwhile; ?>

    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label">Mata Pelajaran</label>

                    <select name="mapel_id" class="form-select" required>

                        <option value="">Pilih Mata Pelajaran</option>

                        <?php while ($mapel = mysqli_fetch_assoc($query_mapel)) : ?>

                            <option
                                value="<?= (int) $mapel['id']; ?>"
                                <?= ($mapel['id'] == $data['mapel_id']) ? 'selected' : ''; ?>
                            >
                                <?= aman($mapel['nama_mapel']); ?>
                                (<?= aman($mapel['kode_mapel']); ?>)
                            </option>

                        <?php endwhile; ?>

                    </select>
                </div>

                <button type="submit" name="edit" class="btn btn-simpan">
                    <i class="bi bi-save"></i>
                    Simpan Perubahan
                </button>

                <a href="daftar_mengajar.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i>
                    Kembali
                </a>

            </form>

        </div>
    </div>

</div>

<?php require 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php
mysqli_free_result($query);
mysqli_free_result($query_siswa);
mysqli_free_result($query_mapel);

mysqli_close($koneksi);

ob_end_flush();
?>