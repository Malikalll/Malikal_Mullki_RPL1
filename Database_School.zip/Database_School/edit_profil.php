<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: profil.php");
    exit;
}

$id = $_SESSION['id'];
$role = $_SESSION['role'];

$username = trim($_POST['username'] ?? '');

if ($username === '') {
    header("Location: profil.php?status=gagal");
    exit;
}

// Cek username sudah digunakan akun lain
$stmt = mysqli_prepare($koneksi, "
    SELECT id FROM users
    WHERE username = ? AND id != ?
");

mysqli_stmt_bind_param($stmt, "si", $username, $id);
mysqli_stmt_execute($stmt);

if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
    echo "<script>
        alert('Username sudah digunakan!');
        window.location='profil.php';
    </script>";
    exit;
}

mysqli_begin_transaction($koneksi);

try {

    // Update username
    $stmt = mysqli_prepare($koneksi, "
        UPDATE users SET username = ? WHERE id = ?
    ");

    mysqli_stmt_bind_param($stmt, "si", $username, $id);

    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Gagal mengubah username");
    }

    if ($role == 'siswa') {

        $nis = trim($_POST['nis'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $kelas = trim($_POST['kelas'] ?? '');
        $jenis = $_POST['jenis_kelasmin'] ?? '';

        if ($nis === '' || $nama === '' || $kelas === '' ||
            !in_array($jenis, ['L', 'P'], true)) {
            throw new Exception("Data siswa tidak valid");
        }

        $stmt = mysqli_prepare($koneksi, "
            UPDATE siswa
            SET nis = ?, nama = ?, kelas = ?, jenis_kelasmin = ?
            WHERE user_id = ?
        ");

        mysqli_stmt_bind_param(
            $stmt, "ssssi",
            $nis, $nama, $kelas, $jenis, $id
        );

        if (!mysqli_stmt_execute($stmt) || mysqli_stmt_affected_rows($stmt) < 0) {
            throw new Exception("Gagal mengubah profil siswa");
        }

        $_SESSION['nama'] = $nama;
        $_SESSION['kelas'] = $kelas;

    } elseif ($role == 'guru') {

        $nip = trim($_POST['nip'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $jenis = $_POST['jenis_kelamin'] ?? '';

        if ($nip === '' || $nama === '' ||
            !in_array($jenis, ['L', 'P'], true)) {
            throw new Exception("Data guru tidak valid");
        }

        $stmt = mysqli_prepare($koneksi, "
            UPDATE guru
            SET nip = ?, nama = ?, jenis_kelamin = ?
            WHERE user_id = ?
        ");

        mysqli_stmt_bind_param(
            $stmt, "sssi",
            $nip, $nama, $jenis, $id
        );

        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Gagal mengubah profil guru");
        }

        $_SESSION['nama'] = $nama;

    } elseif ($role == 'admin') {

        // Admin hanya memiliki data username di tabel users.
        $_SESSION['nama'] = $username;

    } else {
        throw new Exception("Role tidak valid");
    }

    $_SESSION['username'] = $username;

    mysqli_commit($koneksi);

    header("Location: profil.php?status=berhasil");
    exit;

} catch (Exception $e) {

    mysqli_rollback($koneksi);

    header("Location: profil.php?status=gagal");
    exit;
}