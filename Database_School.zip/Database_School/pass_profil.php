<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: profil.php");
    exit;
}

$id = $_SESSION['id'];

$password_lama = $_POST['password_lama'] ?? '';
$password_baru = $_POST['password_baru'] ?? '';
$konfirmasi = $_POST['konfirmasi_password'] ?? '';

if (
    $password_lama === '' ||
    $password_baru === '' ||
    $konfirmasi === ''
) {
    header("Location: profil.php?status=gagal");
    exit;
}

if (strlen($password_baru) < 8 || $password_baru !== $konfirmasi) {
    echo "<script>
        alert('Password baru minimal 8 karakter dan konfirmasi harus sama!');
        window.location='profil.php';
    </script>";
    exit;
}

// Ambil password dari database
$stmt = mysqli_prepare($koneksi, "
    SELECT password FROM users WHERE id = ?
");

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$data) {
    header("Location: profil.php?status=gagal");
    exit;
}

// Mendukung password hash dan password teks biasa lama
$password_valid = password_verify($password_lama, $data['password'])
    || hash_equals((string) $data['password'], (string) $password_lama);

if (!$password_valid) {
    echo "<script>
        alert('Password lama salah!');
        window.location='profil.php';
    </script>";
    exit;
}

// Simpan password baru dalam bentuk hash
$password_hash = password_hash($password_baru, PASSWORD_DEFAULT);

$stmt = mysqli_prepare($koneksi, "
    UPDATE users SET password = ? WHERE id = ?
");

mysqli_stmt_bind_param($stmt, "si", $password_hash, $id);

if (mysqli_stmt_execute($stmt)) {
    header("Location: profil.php?status=password");
    exit;
}

header("Location: profil.php?status=gagal");
exit;