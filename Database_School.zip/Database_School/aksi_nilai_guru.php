<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true ||
    $_SESSION['role'] !== 'guru') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit;
}

$user_id = $_SESSION['id'];
$aksi = $_POST['aksi'] ?? '';
$kelas = trim($_POST['kelas'] ?? '');
$mapel_id = (int)($_POST['mapel_id'] ?? 0);
$siswa_id = (int)($_POST['siswa_id'] ?? 0);
$nilai_id = (int)($_POST['nilai_id'] ?? 0);

function kembaliNilai($status, $kelas, $mapel_id) {
    header("Location: nilai_siswa_guru.php?kelas=" .
        urlencode($kelas) . "&mapel_id=" . $mapel_id . "&status=" . $status);
    exit;
}

if ($kelas === '' || $mapel_id <= 0) {
    header("Location: dashboard.php");
    exit;
}

// Pastikan guru mengajar kelas dan mapel tersebut
$sql = "SELECT COUNT(*) AS total
        FROM mengajar
        JOIN siswa ON mengajar.siswa_id = siswa.id
        JOIN mapel ON mengajar.mapel_id = mapel.id
        JOIN guru ON mapel.guru_id = guru.id
        WHERE guru.user_id = ?
          AND siswa.kelas = ?
          AND mapel.id = ?";

$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "isi", $user_id, $kelas, $mapel_id);
mysqli_stmt_execute($stmt);

$akses = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($akses['total'] == 0) {
    die("Akses ditolak.");
}

// Pastikan siswa memang berada di kelas tersebut
$stmt = mysqli_prepare($koneksi, "
    SELECT id FROM siswa WHERE id = ? AND kelas = ?
");

mysqli_stmt_bind_param($stmt, "is", $siswa_id, $kelas);
mysqli_stmt_execute($stmt);

if (!mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))) {
    die("Data siswa tidak valid.");
}

// Hapus nilai
if ($aksi === 'hapus') {

    $stmt = mysqli_prepare($koneksi, "
        DELETE FROM nilai_rapor
        WHERE id = ? AND siswa_id = ? AND mapel_id = ?
    ");

    mysqli_stmt_bind_param($stmt, "iii", $nilai_id, $siswa_id, $mapel_id);

    if (mysqli_stmt_execute($stmt)) {
        kembaliNilai('berhasil', $kelas, $mapel_id);
    }

    kembaliNilai('gagal', $kelas, $mapel_id);
}

// Ambil nilai dari form
$kkm = $_POST['nilai_kkm'] ?? '';
$pengetahuan = $_POST['nilai_pengetahuan'] ?? '';
$keterampilan = $_POST['nilai_keterampilan'] ?? '';

$angka = [$kkm, $pengetahuan, $keterampilan];

foreach ($angka as $nilai) {
    if (!is_numeric($nilai) || $nilai < 0 || $nilai > 100) {
        kembaliNilai('gagal', $kelas, $mapel_id);
    }
}

$kkm = (int)$kkm;
$pengetahuan = (int)$pengetahuan;
$keterampilan = (int)$keterampilan;

$nilai_akhir = round(($pengetahuan + $keterampilan) / 2);

$keterangan = ($nilai_akhir >= $kkm)
    ? 'Lulus'
    : 'Tidak Lulus';


// Tambah nilai
if ($aksi === 'tambah') {

    // Periksa apakah nilai siswa sudah ada
    $stmt = mysqli_prepare($koneksi, "
        SELECT id
        FROM nilai_rapor
        WHERE siswa_id = ? AND mapel_id = ?
    ");

    if (!$stmt) {
        die("Gagal menyiapkan pengecekan: " . mysqli_error($koneksi));
    }

    mysqli_stmt_bind_param($stmt, "ii", $siswa_id, $mapel_id);

    if (!mysqli_stmt_execute($stmt)) {
        die("Gagal mengecek nilai: " . mysqli_stmt_error($stmt));
    }

    $cek = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($cek) > 0) {
        die("Nilai siswa untuk mata pelajaran ini sudah tersedia.");
    }

    mysqli_stmt_close($stmt);

    // Simpan nilai baru
    $stmt = mysqli_prepare($koneksi, "
        INSERT INTO nilai_rapor
        (
            siswa_id,
            mapel_id,
            nilai_kkm,
            nilai_pengetahuan,
            nilai_keterampilan,
            keterangan
        )
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        die("Gagal menyiapkan INSERT: " . mysqli_error($koneksi));
    }

    mysqli_stmt_bind_param(
        $stmt,
        "iiiiis",
        $siswa_id,
        $mapel_id,
        $kkm,
        $pengetahuan,
        $keterampilan,
        $keterangan
    );

    if (mysqli_stmt_execute($stmt)) {
        kembaliNilai('berhasil', $kelas, $mapel_id);
    } else {
        die("ERROR INSERT NILAI: " . mysqli_stmt_error($stmt));
    }
}


// Edit nilai
if ($aksi === 'edit') {

    $stmt = mysqli_prepare($koneksi, "
        UPDATE nilai_rapor
        SET nilai_kkm = ?,
            nilai_pengetahuan = ?,
            nilai_keterampilan = ?,
            keterangan = ?
        WHERE id = ?
          AND siswa_id = ?
          AND mapel_id = ?
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "iiiiiii",
        $kkm,
        $pengetahuan,
        $keterampilan,
        $keterangan,
        $nilai_id,
        $siswa_id,
        $mapel_id
    );

    if (mysqli_stmt_execute($stmt)) {
        kembaliNilai('berhasil', $kelas, $mapel_id);
    }

    kembaliNilai('gagal', $kelas, $mapel_id);
}

header("Location: dashboard.php");
exit;
