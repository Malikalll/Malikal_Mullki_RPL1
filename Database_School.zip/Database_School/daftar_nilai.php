<?php
session_start();
ob_start();

require_once 'koneksi.php';
require_once 'navbar1.php';

// Pastikan siswa sudah login
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

// Batasi hanya untuk siswa
if ($_SESSION['role'] !== 'siswa') {
    header("Location: dashboard.php");
    exit;
}

$user_id = $_SESSION['id'];

// Ambil data siswa berdasarkan akun login
$sql_siswa = "SELECT id, nis, nama, kelas
              FROM siswa
              WHERE user_id = ?
              LIMIT 1";

$stmt = mysqli_prepare($koneksi, $sql_siswa);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$data_siswa = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$data_siswa) {
    die("Data siswa tidak ditemukan.");
}

$siswa_id = $data_siswa['id'];

// Ambil seluruh nilai milik siswa
$sql = "SELECT
            nilai_rapor.id,
            mapel.nama_mapel,
            mapel.kode_mapel,
            nilai_rapor.nilai_kkm,
            nilai_rapor.nilai_pengetahuan,
            nilai_rapor.nilai_keterampilan,
            nilai_rapor.keterangan
        FROM nilai_rapor
        JOIN mapel ON nilai_rapor.mapel_id = mapel.id
        WHERE nilai_rapor.siswa_id = ?
        ORDER BY mapel.nama_mapel ASC";

$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "i", $siswa_id);
mysqli_stmt_execute($stmt);

$query = mysqli_stmt_get_result($stmt);

function amanDaftarNilai($teks) {
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Daftar Nilai - SIACAD</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>
        body {
            background: #f8f9fc;
            color: #334155;
            font-family: Arial, sans-serif;
        }

        .nilai-page {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 16px;
        }

        .nilai-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,.04);
        }

        .nilai-header {
            padding: 24px;
            border-bottom: 1px solid #e5e7eb;
        }

        .nilai-title {
            color: #4f46e5;
            font-size: 25px;
            font-weight: 700;
            margin-bottom: 7px;
        }

        .nilai-subtitle {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 0;
        }

        .identitas-siswa {
            display: flex;
            flex-wrap: wrap;
            gap: 12px 25px;
            margin-top: 18px;
            font-size: 14px;
        }

        .identitas-siswa span {
            color: #64748b;
        }

        .identitas-siswa strong {
            color: #334155;
        }

        .nilai-body {
            padding: 24px;
        }

        .table {
            margin-bottom: 0;
            white-space: nowrap;
        }

        .table thead th {
            background: #f1f5f9;
            color: #475569;
            font-size: 13px;
            font-weight: 700;
            padding: 14px 12px;
        }

        .table tbody td {
            padding: 13px 12px;
            font-size: 14px;
            color: #475569;
        }

        .badge-nilai {
            display: inline-block;
            min-width: 38px;
            padding: 6px 9px;
            border-radius: 6px;
            background: #eef2ff;
            color: #4f46e5;
            font-weight: 700;
        }

        .badge-akhir {
            background: #dcfce7;
            color: #15803d;
        }

        .status-lulus {
            color: #198754;
            font-weight: 700;
        }

        .status-tidak {
            color: #dc3545;
            font-weight: 700;
        }

        .empty-data {
            padding: 40px 15px !important;
            color: #64748b !important;
        }

        @media (max-width: 576px) {
            .nilai-page {
                margin: 20px auto;
                padding: 0 10px;
            }

            .nilai-header,
            .nilai-body {
                padding: 17px;
            }

            .nilai-title {
                font-size: 21px;
            }
        }
    </style>
</head>

<body>

<?php require_once 'navbar1.php'; ?>

<main class="nilai-page">

    <div class="nilai-card">

        <div class="nilai-header">

            <h1 class="nilai-title">
                <i class="bi bi-journal-check"></i>
                Daftar Nilai Saya
            </h1>

            <p class="nilai-subtitle">
                Berikut merupakan hasil penilaian akademik kamu.
            </p>

            <div class="identitas-siswa">

                <div>
                    <span>Nama:</span>
                    <strong><?= amanDaftarNilai($data_siswa['nama']); ?></strong>
                </div>

                <div>
                    <span>NIS:</span>
                    <strong><?= amanDaftarNilai($data_siswa['nis']); ?></strong>
                </div>

                <div>
                    <span>Kelas:</span>
                    <strong><?= amanDaftarNilai($data_siswa['kelas']); ?></strong>
                </div>

            </div>

        </div>

        <div class="nilai-body">

            <div class="table-responsive">

                <table class="table table-bordered table-hover text-center align-middle">

                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Mata Pelajaran</th>
                            <th>Kode Mapel</th>
                            <th>KKM</th>
                            <th>Pengetahuan</th>
                            <th>Keterampilan</th>
                            <th>Nilai Akhir</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (mysqli_num_rows($query) > 0): ?>

                        <?php $no = 1; ?>

                        <?php while ($row = mysqli_fetch_assoc($query)): ?>

                            <?php
                            $nilai_akhir = round(
                                ($row['nilai_pengetahuan'] +
                                 $row['nilai_keterampilan']) / 2
                            );

                            $lulus = $nilai_akhir >= $row['nilai_kkm'];
                            ?>

                            <tr>

                                <td><?= $no++; ?></td>

                                <td class="text-start">
                                    <strong>
                                        <?= amanDaftarNilai($row['nama_mapel']); ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= amanDaftarNilai($row['kode_mapel']); ?>
                                </td>

                                <td>
                                    <?= (int)$row['nilai_kkm']; ?>
                                </td>

                                <td>
                                    <span class="badge-nilai">
                                        <?= (int)$row['nilai_pengetahuan']; ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="badge-nilai">
                                        <?= (int)$row['nilai_keterampilan']; ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="badge-nilai badge-akhir">
                                        <?= $nilai_akhir; ?>
                                    </span>
                                </td>

                                <td>
                                    <?php if ($lulus): ?>
                                        <span class="status-lulus">
                                            <i class="bi bi-check-circle-fill"></i>
                                            Lulus
                                        </span>
                                    <?php else: ?>
                                        <span class="status-tidak">
                                            <i class="bi bi-x-circle-fill"></i>
                                            Tidak Lulus
                                        </span>
                                    <?php endif; ?>
                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="8" class="empty-data">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                Belum ada nilai yang diberikan oleh guru.
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</main>

<?php require 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($koneksi);
ob_end_flush();
?>
