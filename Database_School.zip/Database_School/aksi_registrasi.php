<?php
require_once 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: registrasi_siswa.php");
    exit;
}

// Ambil data form
$nis = trim($_POST['nis'] ?? '');
$nama = trim($_POST['nama'] ?? '');
$kelas = trim($_POST['kelas'] ?? '');
$jenis_kelasmin = $_POST['jenis_kelasmin'] ?? '';
$username = trim($_POST['username'] ?? '');
$pass = $_POST['pass'] ?? '';

// Validasi input
if (
    $nis === '' ||
    $nama === '' ||
    $kelas === '' ||
    $username === '' ||
    $pass === '' ||
    !in_array($jenis_kelasmin, ['L', 'P'], true)
) {
    echo "<script>
            alert('Semua data wajib diisi!');
            window.location.href='registrasi.php';
          </script>";
    exit;
}

// Enkripsi password
$password = password_hash($pass, PASSWORD_DEFAULT);

// Mulai transaksi
mysqli_begin_transaction($koneksi);

try {

    // Cek NIS
    $cek_nis = mysqli_prepare(
        $koneksi,
        "SELECT id FROM siswa WHERE nis = ?"
    );

    mysqli_stmt_bind_param($cek_nis, "s", $nis);
    mysqli_stmt_execute($cek_nis);
    mysqli_stmt_store_result($cek_nis);

    if (mysqli_stmt_num_rows($cek_nis) > 0) {
        throw new Exception("NIS sudah terdaftar!");
    }

    // Cek username
    $cek_username = mysqli_prepare(
        $koneksi,
        "SELECT id FROM users WHERE username = ?"
    );

    mysqli_stmt_bind_param($cek_username, "s", $username);
    mysqli_stmt_execute($cek_username);
    mysqli_stmt_store_result($cek_username);

    if (mysqli_stmt_num_rows($cek_username) > 0) {
        throw new Exception("Username sudah digunakan!");
    }

    // Simpan akun users
    $sql_user = "INSERT INTO users
                 (username, password, role, created_at)
                 VALUES (?, ?, 'siswa', NOW())";

    $stmt_user = mysqli_prepare($koneksi, $sql_user);

    mysqli_stmt_bind_param(
        $stmt_user,
        "ss",
        $username,
        $password
    );

    if (!mysqli_stmt_execute($stmt_user)) {
        throw new Exception("Gagal membuat akun!");
    }

    // Ambil ID user
    $user_id = mysqli_insert_id($koneksi);

    // Simpan profil siswa
    $sql_siswa = "INSERT INTO siswa
                  (user_id, nis, nama, kelas, jenis_kelasmin)
                  VALUES (?, ?, ?, ?, ?)";

    $stmt_siswa = mysqli_prepare($koneksi, $sql_siswa);

    mysqli_stmt_bind_param(
        $stmt_siswa,
        "issss",
        $user_id,
        $nis,
        $nama,
        $kelas,
        $jenis_kelasmin
    );

    if (!mysqli_stmt_execute($stmt_siswa)) {
        throw new Exception("Gagal menyimpan profil siswa!");
    }

    // Simpan transaksi
    mysqli_commit($koneksi);

    echo "<script>
            alert('Registrasi berhasil! Silakan login.');
            window.location.href='login.php';
          </script>";

} catch (Exception $e) {

    mysqli_rollback($koneksi);

    $pesan = json_encode(
        $e->getMessage(),
        JSON_HEX_TAG | JSON_HEX_APOS |
        JSON_HEX_QUOT | JSON_HEX_AMP
    );

    echo "<script>
            alert($pesan);
            window.location.href='registrasi.php';
          </script>";
}

mysqli_close($koneksi);
?>
