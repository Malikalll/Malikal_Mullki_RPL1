<?php
session_start();
require_once 'navbar1.php';
require_once 'koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

$id = $_SESSION['id'];
$role = $_SESSION['role'];

$stmt = mysqli_prepare($koneksi, "SELECT username FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$user) {
    die("Data pengguna tidak ditemukan.");
}

$username = $user['username'];
$nama = $username;
$profil = [];

if ($role == 'siswa') {
    $stmt = mysqli_prepare($koneksi, "
        SELECT nis, nama, kelas, jenis_kelasmin
        FROM siswa WHERE user_id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $profil = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$profil) {
        die("Data siswa tidak ditemukan.");
    }

    $nama = $profil['nama'];

} elseif ($role == 'guru') {
    $stmt = mysqli_prepare($koneksi, "
        SELECT nip, nama, jenis_kelamin
        FROM guru WHERE user_id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $profil = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$profil) {
        die("Data guru tidak ditemukan.");
    }

    $nama = $profil['nama'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Profil Saya - SIACAD</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.4/css/dataTables.bootstrap5.min.css">
  
</head>

<body class="bg-light">

<div class="container py-5">

    <div class="row justify-content-center">
        <div class="col-lg-7">

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0">
                        <i class="bi bi-person-circle"></i> Profil Saya
                    </h5>
                </div>

                <div class="card-body p-4">

                    <?php if (isset($_GET['status'])): ?>
                        <?php if ($_GET['status'] == 'berhasil'): ?>
                            <div class="alert alert-success">
                                Profil berhasil diperbarui.
                            </div>
                        <?php elseif ($_GET['status'] == 'password'): ?>
                            <div class="alert alert-success">
                                Password berhasil diganti.
                            </div>
                        <?php elseif ($_GET['status'] == 'gagal'): ?>
                            <div class="alert alert-danger">
                                Terjadi kesalahan saat memperbarui data.
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="text-center mb-4">
                        <i class="bi bi-person-circle text-primary"
                           style="font-size: 80px;"></i>

                        <h4 class="mt-2 mb-1">
                            <?= htmlspecialchars($nama) ?>
                        </h4>

                        <span class="badge bg-secondary">
                            <?= htmlspecialchars(ucfirst($role)) ?>
                        </span>
                    </div>

                    <form action="edit_profil.php" method="POST">

                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username"
                                   class="form-control"
                                   value="<?= htmlspecialchars($username) ?>"
                                   required>
                        </div>

                        <?php if ($role == 'siswa'): ?>

                            <div class="mb-3">
                                <label class="form-label">NIS</label>
                                <input type="text" name="nis"
                                       class="form-control"
                                       value="<?= htmlspecialchars($profil['nis']) ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" name="nama"
                                       class="form-control"
                                       value="<?= htmlspecialchars($profil['nama']) ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Kelas</label>
                                <input type="text" name="kelas"
                                       class="form-control"
                                       value="<?= htmlspecialchars($profil['kelas']) ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Jenis Kelamin</label>
                                <select name="jenis_kelasmin" class="form-select" required>
                                    <option value="L" <?= $profil['jenis_kelasmin'] == 'L' ? 'selected' : '' ?>>
                                        Laki-laki
                                    </option>
                                    <option value="P" <?= $profil['jenis_kelasmin'] == 'P' ? 'selected' : '' ?>>
                                        Perempuan
                                    </option>
                                </select>
                            </div>

                        <?php elseif ($role == 'guru'): ?>

                            <div class="mb-3">
                                <label class="form-label">NIP</label>
                                <input type="text" name="nip"
                                       class="form-control"
                                       value="<?= htmlspecialchars($profil['nip']) ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" name="nama"
                                       class="form-control"
                                       value="<?= htmlspecialchars($profil['nama']) ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="form-select" required>
                                    <option value="L" <?= $profil['jenis_kelamin'] == 'L' ? 'selected' : '' ?>>
                                        Laki-laki
                                    </option>
                                    <option value="P" <?= $profil['jenis_kelamin'] == 'P' ? 'selected' : '' ?>>
                                        Perempuan
                                    </option>
                                </select>
                            </div>

                        <?php endif; ?>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-save"></i> Simpan Perubahan
                        </button>

                    </form>

                </div>
            </div>

            <!-- Ganti Password -->
            <div class="card shadow-sm border-0">
                <div class="card-header bg-dark text-white py-3">
                    <h5 class="mb-0">
                        <i class="bi bi-shield-lock"></i> Ganti Password
                    </h5>
                </div>

                <div class="card-body p-4">

                    <form action="pass_profil.php" method="POST">

                        <div class="mb-3">
                            <label class="form-label">Password Lama</label>
                            <input type="password" name="password_lama"
                                   class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password Baru</label>
                            <input type="password" name="password_baru"
                                   class="form-control" minlength="8" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Konfirmasi Password Baru</label>
                            <input type="password" name="konfirmasi_password"
                                   class="form-control" minlength="8" required>
                        </div>

                        <button type="submit" class="btn btn-dark w-100">
                            <i class="bi bi-key"></i> Ganti Password
                        </button>

                    </form>

                </div>
            </div>

            <div class="text-center mt-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
                </a>
            </div>

        </div>
    </div>

</div>

</body>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>
  
</html>