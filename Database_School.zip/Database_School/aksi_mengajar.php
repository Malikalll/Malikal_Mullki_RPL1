<?php
require_once 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $aksi = $_POST['aksi'] ?? '';

    if ($aksi == 'edit') {
        $id = (int) $_POST['id'];
        $siswa_id = (int) $_POST['siswa_id'];
        $mapel_id = (int) $_POST['mapel_id'];

        $sql = "UPDATE mengajar
                SET siswa_id = ?, mapel_id = ?
                WHERE id = ?";

        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, "iii", $siswa_id, $mapel_id, $id);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                    alert('Data mengajar berhasil diubah!');
                    window.location.href='daftar_mengajar.php';
                  </script>";
        } else {
            echo "Gagal mengubah data: " . mysqli_error($koneksi);
        }

    } elseif ($aksi == 'hapus') {
        $id = (int) $_POST['id'];

        $sql = "DELETE FROM mengajar WHERE id = ?";
        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                    alert('Data mengajar berhasil dihapus!');
                    window.location.href='daftar_mengajar.php';
                  </script>";
        } else {
            echo "Gagal menghapus data: " . mysqli_error($koneksi);
        }
    }
}
?>